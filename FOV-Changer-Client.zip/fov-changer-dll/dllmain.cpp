// dllmain.cpp : Defines the entry point for the DLL application.
// Coding style:
// Members:
// m_hotkey => for normal stuff
// m_KeyListner => for classes
//
// Camelcase for most stuff expect classes and global functions
#include "pch.h"

#include "module.h"
#include "game.h"
#include "utils\mem.h"
#include "utils\proc.h"
#include "network/network.h"
#include "SDK/KeyListener.h"


// Setup console before everything
class SetupLogger { public: FILE* m_F; SetupLogger() { AllocConsole(); freopen_s(&m_F, "CONOUT$", "w", stdout);} };
extern const std::shared_ptr<SetupLogger> __setupLogger = std::make_shared<SetupLogger>();


// Global core things that get "extern -ed"
extern const std::shared_ptr<GameManager> gameManager = std::make_shared<GameManager>();
extern const std::shared_ptr<ModuleManager> moduleManager = std::make_shared<ModuleManager>();
//extern const std::shared_ptr<Network> network = std::make_shared<Network>();


DWORD WINAPI InjectedThread(HMODULE hModule)
{
    // Create console
    //AllocConsole();
    //FILE* f;
    //freopen_s(&f, "CONOUT$", "w", stdout);

    std::cout << "FOV Changer Client :: Press END to exit!" << std::endl;

    // Init minhook
    if (MH_Initialize() != MH_OK)
        std::cout << "Minhook init failed!" << std::endl;
    else
        std::cout << "Minhook successfully initialized." << std::endl;

    //network->startThread();
    moduleManager->initGameData();

    while (true)
    {
        // END
        if (GetAsyncKeyState(VK_END) & 1 || gameManager->c_KeyListener->END)
        {
            break;
        }

        moduleManager->loopHotkeys();

        Sleep(5);
    }

    // Uninit minhook
    MH_Uninitialize();

    // cleanup & eject
    fclose(__setupLogger->m_F);
    FreeConsole();
    FreeLibraryAndExitThread(hModule, 0);
    return 0;
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
    {
        CloseHandle(CreateThread(nullptr, 0, (LPTHREAD_START_ROUTINE)InjectedThread, hModule, 0, nullptr));
    }
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

