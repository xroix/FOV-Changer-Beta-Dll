#include "pch.h"
#include "module.h"

#include "modules/zoom.h"
#include "modules/nametag.h"
#include "modules/freelook.h"


Signature::Signature(const std::string& signature)
{
	this->_Mode = 0;
	this->m_signature = signature;
	this->m_aob1 = "";
	this->m_aob2 = "";
	this->m_aobLength = 0;
}

Signature::Signature(const std::string& signature, int aobLength, const char* aob)
{
	this->_Mode = 1;
	this->m_signature = signature;
	this->m_aob1 = aob;
	this->m_aob2 = "";
	this->m_aobLength = aobLength;
}

Signature::Signature(const std::string& signature, int aobLength, const char* aob1, const char* aob2)
{
	this->_Mode = 2;
	this->m_signature = signature;
	this->m_aob1 = aob1;
	this->m_aob2 = aob2;
	this->m_aobLength = aobLength;
}

Signature::~Signature()
{
	this->deactivate();
}

void Signature::initGameData()
{
	// Get location of signature
	m_addr = mem::GetAddressFromSignature("Minecraft.Windows.exe", m_signature.c_str());

	if (_Mode == 2)
	{
		// Set aob1
		mem::Patch((BYTE*)m_addr, (BYTE*)m_aob1, m_aobLength);
	}
}

void Signature::activate()
{
	switch (_Mode)
	{
	case 0:
		break;

	case 1:
		mem::Nop((BYTE*)m_addr, m_aobLength);
		break;

	case 2:
		mem::Patch((BYTE*)m_addr, (BYTE*)m_aob2, m_aobLength);
		break;
	}
}

void Signature::deactivate()
{
	switch (_Mode)
	{
	case 0:
		break;

	case 1:
		mem::Patch((BYTE*)m_addr, (BYTE*)m_aob1, m_aobLength);
		break;

	case 2:
		mem::Patch((BYTE*)m_addr, (BYTE*)m_aob1, m_aobLength);
		break;
	}
}

Option::Option(std::string optionName, int optionType, void* defaultValue)
{
	this->m_optionType = optionType;
	this->m_optionName = optionName;
	 
	this->m_value = defaultValue;
	this->m_defaultValue = defaultValue;	
}

template<class T>
T Option::get()
{
	return (T)m_value;
}


ModuleManager::ModuleManager()
{
	// Add here modules
	this->m_modules.push_back(std::make_shared<Zoom>());
	this->m_modules.push_back(std::make_shared<Nametag>());
	this->m_modules.push_back(std::make_shared<Freelook>());
}

ModuleManager::~ModuleManager()
{
	// Call onStop for all modules
	for (auto const& module_ : this->m_modules)
	{
		module_->onStop();
	}
}

void ModuleManager::initGameData()
{
	// Call initGameData for alls modules
	for (auto const& module_ : m_modules)
	{
		module_->initGameData();
	}

	// Call onStart for all modules after previous step is complete
	for (auto const& module_ : m_modules)
	{
		module_->onStart();
	}
}

void ModuleManager::loopHotkeys()
{
	for (auto const& module_ : m_modules)
	{
		if (!module_->m_hotkey) continue;

		if (*module_->m_hotkey)
		{
			if (!module_->m_pressed)
			{
				module_->onPress();
				module_->m_pressed = true;
			}

		} else
		{
			if (module_->m_pressed)
			{
				module_->onRelease();
				module_->m_pressed = false;
			}
		}
	}
}